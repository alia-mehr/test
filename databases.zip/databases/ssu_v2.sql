-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2016 at 03:53 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ssu`
--
CREATE DATABASE IF NOT EXISTS `ssu` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `ssu`;

-- --------------------------------------------------------

--
-- Table structure for table `configuration`
--

CREATE TABLE IF NOT EXISTS `configuration` (
  `id_config` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `changed` datetime NOT NULL,
  `username` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `site_title` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `site_description` varchar(150) COLLATE utf8_persian_ci DEFAULT NULL,
  `site_created` datetime NOT NULL,
  `site_about` mediumtext COLLATE utf8_persian_ci,
  `notification` varchar(1000) COLLATE utf8_persian_ci DEFAULT NULL,
  `ip_creator` varchar(40) CHARACTER SET latin1 NOT NULL,
  `ip_changer` varchar(40) CHARACTER SET latin1 NOT NULL,
  `max_up_size` int(10) unsigned DEFAULT NULL,
  `mime_allowed` varchar(20000) COLLATE utf8_persian_ci DEFAULT NULL,
  `upload_location` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `template` mediumtext COLLATE utf8_persian_ci,
  `message_allowed` tinyint(1) NOT NULL,
  `error_allowed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `configuration`
--

INSERT INTO `configuration` (`id_config`, `changed`, `username`, `password`, `email`, `site_title`, `site_description`, `site_created`, `site_about`, `notification`, `ip_creator`, `ip_changer`, `max_up_size`, `mime_allowed`, `upload_location`, `template`, `message_allowed`, `error_allowed`) VALUES
(1, '2016-03-27 10:36:57', 'admin', 'admin', 'alia_mehr@yahoo.com', 'Simcrip Uploader', 'a free upload center', '2016-03-26 15:09:53', 'this script is free. in version 0.1', 'In the name of Allah\r\nWelcome to Simcrip Uploader :)', '::1', '::1', 1048576, '''image/gif'',''image/jpeg'',''image/pjpeg'',''image/png''', './uploads/', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id_message` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `url` varchar(100) COLLATE utf8_persian_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id_message`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
