-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2016 at 11:01 AM
-- Server version: 5.6.11
-- PHP Version: 5.5.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ssu`
--
CREATE DATABASE IF NOT EXISTS `ssu` DEFAULT CHARACTER SET utf8 COLLATE utf8_persian_ci;
USE `ssu`;

-- --------------------------------------------------------

--
-- Table structure for table `configuration`
--

CREATE TABLE IF NOT EXISTS `configuration` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `changed` datetime NOT NULL,
  `username` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `site_title` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `site_description` varchar(150) COLLATE utf8_persian_ci DEFAULT NULL,
  `site_created` datetime NOT NULL,
  `site_about` mediumtext COLLATE utf8_persian_ci,
  `notification` varchar(1000) COLLATE utf8_persian_ci DEFAULT NULL,
  `ip_creator` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `ip_changer` varchar(40) COLLATE utf8_persian_ci NOT NULL,
  `max_up_size` int(10) unsigned DEFAULT NULL,
  `mime_allowed` varchar(20000) COLLATE utf8_persian_ci DEFAULT NULL,
  `upload_location` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `template` mediumtext COLLATE utf8_persian_ci,
  `error_allowed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
